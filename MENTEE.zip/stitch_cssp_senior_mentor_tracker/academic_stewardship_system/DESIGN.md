---
name: Academic Stewardship System
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#41484a'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#71787b'
  outline-variant: '#c0c8cb'
  surface-tint: '#386571'
  primary: '#003742'
  on-primary: '#ffffff'
  primary-container: '#1f4e5a'
  on-primary-container: '#91becc'
  inverse-primary: '#a0cedc'
  secondary: '#7a5900'
  on-secondary: '#ffffff'
  secondary-container: '#fdc750'
  on-secondary-container: '#725300'
  tertiary: '#003a26'
  on-tertiary: '#ffffff'
  tertiary-container: '#005338'
  on-tertiary-container: '#57cb9a'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#bceaf9'
  primary-fixed-dim: '#a0cedc'
  on-primary-fixed: '#001f26'
  on-primary-fixed-variant: '#1d4d59'
  secondary-fixed: '#ffdea2'
  secondary-fixed-dim: '#f4be49'
  on-secondary-fixed: '#261900'
  on-secondary-fixed-variant: '#5c4200'
  tertiary-fixed: '#85f8c4'
  tertiary-fixed-dim: '#68dba9'
  on-tertiary-fixed: '#002114'
  on-tertiary-fixed-variant: '#005137'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
  data-metric:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 0.75rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

The design system establishes an authoritative, composed, and institutional atmosphere tailored for academic leadership, faculty oversight, and mentor coordination at SR University. It bridges institutional rigor with contemporary enterprise software utility.

### Brand Personality & Emotional Impact
- **Scholarly Authority:** Imparts trust, accountability, and institutional excellence through deliberate pacing, crisp alignment, and balanced visual weight.
- **Actionable Clarity:** Avoids visual noise to reduce cognitive load during high-volume tracking of student progress, mentor assignments, and compliance metrics.
- **Composed Prestige:** Blends deep collegiate teal with refined gold accents, balancing collegiate heritage with high-efficiency productivity tools.

### Visual Style
- **Corporate / Modern Editorial Hybrid:** A precise, data-dense design framework built around structured card layouts, subtle hairline borders (`#E2E8F0`), restrained background depth, and status-driven visual markers.
- **Information Architecture Focus:** Emphasizes scanning efficiency, compact metric cards, structured ledger views, and immediate identification of academic risks via color-coded status badges.

## Colors

The palette balances institutional gravitas with functional status differentiation across complex mentor rosters and verification states.

### Core Hierarchy
- **Primary Teal (`#1F4E5A`):** The foundational anchor representing institutional permanence. Used for primary navigation, critical interactive controls, authoritative headers, and active state indicators.
- **Secondary Gold (`#D4A22E`):** The stewardship accent. Applied sparingly to highlight honors, institution badges, active indicators, and key metric callouts.
- **Canvas & Neutral Surfaces:**
  - Base Background: `#F8FAFC` (Slate 50) delivers low-glare reading comfort during extended review sessions.
  - Surface Containers: `#FFFFFF` (White) maintains clean containment for cards, modals, and data grids.
  - Borders & Dividers: `#E2E8F0` (Slate 200) ensures structured structural definition without optical clutter.
- **Text & Foreground:**
  - Primary Text: `#0F172A` (Slate 900) for headers, values, and high-priority data points.
  - Secondary Text: `#334155` (Slate 700) for body copy, labels, and supporting details.
  - Muted/Tertiary: `#64748B` (Slate 500) for timestamps, secondary metadata, and inactive icons.

### Status Palette (Semantic Action States)
- **Verified / Updated / Met Targets:** `#059669` (Dark Emerald) text on `#ECFDF5` background; `#10B981` (Emerald) for graphical progress bars and positive indicators.
- **Pending / Warning:** `#D97706` (Deep Amber) text on `#FFFBEB` background; `#F59E0B` for alerts requiring mentor review.
- **Below Target / Missing Links / Doubtful:** `#DC2626` (Crimson) text on `#FEF2F2` background; `#EF4444` for unverified entries, delinquent submissions, and missing compliance links.

## Typography

The typography system relies entirely on **Inter** to ensure maximum legibility across dense data tables, hierarchical mentor lists, and dashboard metric widgets.

### Typographic Hierarchy Guidelines
- **Data Metrics & Numerical Summaries:** Use `data-metric` (`24px / 700`) paired with `label-md` uppercase captions to create high-visibility tracking totals.
- **Status & Meta Badges:** Use `label-sm` with tight uppercase tracking (`+0.04em`) to ensure legibility when contained within colored background capsules.
- **Tabular Alignment:** When rendering tabular data, numeric figures and student registration IDs must employ tabular figures (`font-variant-numeric: tabular-nums`) to maintain visual alignment across rows.

## Layout & Spacing

The layout is built upon an 8-point baseline grid with a 12-column responsive layout for desktop displays and a single-column stacked layout for handheld devices.

### Breakpoints & Grid Composition
- **Desktop (1024px and above):** 12-column layout with `2rem` page margins and `1.5rem` gutters. Metric cards typically span 3 or 4 columns; mentor rosters and review logs span 8 to 12 columns.
- **Tablet (768px – 1023px):** 8-column layout with `1.5rem` margins and `1rem` gutters. Stats cards collapse into 2x2 configurations.
- **Mobile (< 768px):** 4-column layout or flex-stack with `1rem` margins and `0.75rem` gutters. Multi-column tables collapse into card-based list items.

### Content Density Rules
- High-frequency data tables prioritize compact density: row heights adhere to a strict `44px` minimum for pointer accessibility with vertical padding governed by `space-sm` (`0.5rem`).
- Visual separation between card containers is maintained with `space-md` (`1rem`) to keep contextual elements grouped naturally.

## Elevation & Depth

Visual hierarchy relies on structural hairline borders combined with soft ambient light layering, eliminating harsh skeuomorphism in favor of crisp administrative clarity.

### Surface Tiers
- **Tier 0 (Page Canvas):** `#F8FAFC`. Base canvas layer for global dashboard views.
- **Tier 1 (Surface Cards & Containers):** `#FFFFFF` paired with border `1px solid #E2E8F0` and `box-shadow: 0 1px 3px 0 rgba(15, 23, 42, 0.04), 0 1px 2px -1px rgba(15, 23, 42, 0.04)`.
- **Tier 2 (Interactive Floating Elements & Dropdowns):** `#FFFFFF` paired with border `1px solid #E2E8F0` and `box-shadow: 0 4px 6px -1px rgba(15, 23, 42, 0.07), 0 2px 4px -2px rgba(15, 23, 42, 0.05)`.
- **Tier 3 (Modals & Critical Action Dialogs):** `#FFFFFF` centered over a backdrop overlay (`rgba(15, 23, 42, 0.45)`) with `box-shadow: 0 20px 25px -5px rgba(15, 23, 42, 0.1), 0 8px 10px -6px rgba(15, 23, 42, 0.06)`.

### Border Accent Rules
- Interactive cards incorporate a left-edge accent border (`3px solid`) inheriting status states (e.g., `#10B981` for completed mentor reviews, `#EF4444` for actionable interventions).

## Shapes

The interface employs a balanced `0.5rem` (Level 2) corner radius, conveying structured precision without sharp, utilitarian rigidity.

### Component Rounding Rules
- **Base Components (Inputs, Regular Cards, Dialogs):** `0.5rem` (`rounded-md`).
- **Surface Panels & Outer Containers:** `0.75rem` to `1rem` (`rounded-lg` / `rounded-xl`) for main application containers.
- **Pills, Badges & Interactive Chips:** Dedicated pill geometry (`9999px`) applied to status indicators, category chips, and avatar containers to distinguish them from rectangular input controls.

## Components

### Brand Navigation Bar
- **Header Shell:** White surface (`#FFFFFF`) pinned to top with hairline bottom border (`#E2E8F0`) and `space-md` vertical padding.
- **Brand Badge:** Displays `CSSP · SR UNIVERSITY` set in `Inter 600` uppercase (`label-sm`). Rendered as a pill capsule with a soft Teal background (`#1F4E5A` at 10% opacity) and dark Teal text (`#1F4E5A`), accented by a subtle gold dot (`#D4A22E`) indicator.

### Stats Cards
- **Structure:** Clean white cards with `space-lg` internal padding, hairline borders, and a top or left-edge indicator bar (`3px`).
- **Metric Content:** Large primary figures (`data-metric`) accompanied by trend percentages and a small status pill indicating variance against target metrics.

### Segmented Tabs
- **Container:** Recessed background (`#F1F5F9`) with `0.5rem` border radius and `space-xs` inner padding.
- **Tabs:** Individual tab items use `label-md`. Active tab is elevated via white background (`#FFFFFF`), crisp shadow (`0 1px 2px rgba(0,0,0,0.05)`), and dark slate text (`#0F172A`). Inactive tabs remain transparent with muted text (`#64748B`).

### Buttons
- **Primary:** Background `#1F4E5A`, text `#FFFFFF`, radius `0.5rem`, padding `0.5rem 1rem`. Hover state transitions to `#163B44`.
- **Secondary / Subtle:** Surface `#FFFFFF`, border `1px solid #CBD5E1`, text `#334155`. Hover state uses `#F8FAFC`.
- **Status / Accent Actions:** Gold button variant with `#D4A22E` background and `#FFFFFF` text for stewardship-specific milestones and commendation actions.

### Badges & Progress Pills
- **Status Capsules:** Fully rounded (`9999px`), padding `0.25rem 0.625rem`. 
  - *Verified:* Green text `#059669`, Green background `#ECFDF5`.
  - *Pending:* Amber text `#D97706`, Amber background `#FFFBEB`.
  - *At Risk:* Red text `#DC2626`, Red background `#FEF2F2`.
- **Progress Trackers:** Horizontal bar with height `6px`, track background `#E2E8F0`, and animated fill color reflecting target completion (`#10B981`, `#F59E0B`, or `#EF4444`).

### List Cards & Mentor Rosters
- **Composition:** Row-based interactive items containing student/mentor avatars (circular, 36px, initials with subtle teal/gold backing), student roll number in `body-sm` muted text, review status badge, and navigation chevron.
- **Dividers:** Soft borders (`#F1F5F9`) separating items, with an alternating subtle hover state (`#F8FAFC`).

### Academic Data Tables
- **Table Headers:** Background `#F8FAFC`, uppercase `label-sm` in `#64748B`, height `40px`, bottom border `1px solid #E2E8F0`.
- **Table Cells:** Height `48px`, `body-md` typography with numeric data utilizing monospace/tabular numerals, actions right-aligned with ghost buttons.